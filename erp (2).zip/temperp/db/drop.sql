use JPR;
-- alter table studentdetail
-- add column photo varchar(300);
select * from studentdetail;
-- drop table studentdetail;